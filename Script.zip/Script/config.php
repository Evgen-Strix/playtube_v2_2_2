<?php
// +------------------------------------------------------------------------+
// | @author Deen Doughouz (DoughouzForest)
// | @author_url 1: http://www.playtubescript.com
// | @author_url 2: http://codecanyon.net/user/doughouzforest
// | @author_email: wowondersocial@gmail.com   
// +------------------------------------------------------------------------+
// | PlayTube - The Ultimate Video Sharing Platform
// | Copyright (c) 2017 PlayTube. All rights reserved.
// +------------------------------------------------------------------------+
header("Location: ./install");
// MySQL Hostname
$sql_db_host = "";
// MySQL Database User
$sql_db_user = "";
// MySQL Database Password
$sql_db_pass = "";
// MySQL Database Name
$sql_db_name = "";

// Site URL
$site_url = ""; // e.g (http://example.com)

// Purchase code
$purchase_code = ""; // Your purchase code, don't give it to anyone. 
?>