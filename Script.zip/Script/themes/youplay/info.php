<?php
$themeName = 'YouPlay';

$themeFolder = 'youplay';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'mailto:wowondersocial@gmail.com';

$themeVirsion = '1.0';
?>