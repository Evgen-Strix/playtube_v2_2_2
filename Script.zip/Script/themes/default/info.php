<?php
$themeName = 'Default';

$themeFolder = 'default';

$themeAuthor = 'Deen Doughouz';

$themeAuthorUrl = 'mailto:wowondersocial@gmail.com';

$themeVirsion = '1.0';
?>